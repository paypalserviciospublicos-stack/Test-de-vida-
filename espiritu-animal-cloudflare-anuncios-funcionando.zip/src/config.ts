// Si ya tienes dominio, escríbelo aquí (ej: "https://tudominio.com/").
// Si lo dejas vacío, se usa la URL actual de la página.
export const SITE_URL = "";

// Tamaños de los banners (deben coincidir con los de tu zona en Adsterra)
export const AD_TOP_SIZE = { width: 320, height: 50 }; // usa 728x90 si tu zona es de ese tamaño
export const AD_RESULT_SIZE = { width: 300, height: 250 };
