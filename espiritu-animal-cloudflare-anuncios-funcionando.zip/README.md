# Espíritu Animal — Cloudflare Pages

## Configuración de Cloudflare Pages

- Framework preset: **None / Ninguno**
- Build command: `unzip -o espiritu-animal-cloudflare.zip && npm install && npm run build`
- Build output directory: `dist`

El repositorio debe contener el archivo `espiritu-animal-cloudflare.zip` en su raíz y la rama de producción configurada en Cloudflare debe coincidir exactamente con la rama que contiene el proyecto en GitHub (por ejemplo, `principal` o `main`).

El archivo `public/_redirects` se copia a `dist` durante la compilación y permite que las rutas de la aplicación de una sola página vuelvan a `index.html`.

Si el ZIP se descomprime en el repositorio antes de subirlo, también se puede compilar con `npm install && npm run build`, siempre que `package.json` esté en la raíz del repositorio.
