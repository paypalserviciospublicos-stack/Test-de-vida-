# ¿Cuál es tu Espíritu Animal?

Test de personalidad en HTML + Vite (misma estructura que MiTube).

## Cloudflare Pages
- Comando de compilación: `npm run build`
- Directorio de salida: `dist`

## Antes de publicar
- Cambia `TU-DOMINIO.com` en los meta tags de `index.html`.
- Completa `SITE_URL` en el script.
- Pega tus códigos de Adsterra en `#adTop` y `#adResult` (zonas distintas).
