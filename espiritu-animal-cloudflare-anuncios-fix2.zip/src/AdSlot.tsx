import { useEffect, useRef } from "react";

type Props = { code: string; width: number; height: number; label: string };

export default function AdSlot({ code, width, height, label }: Props) {
  const hostRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;
    host.replaceChildren();
    const parsed = new DOMParser().parseFromString(code, "text/html");
    const scriptNodes: HTMLScriptElement[] = [];

    // Mount ad containers before loading the provider scripts.
    for (const node of Array.from(parsed.body.childNodes)) {
      if (node.nodeType === Node.TEXT_NODE && !node.textContent?.trim()) continue;
      if (node instanceof HTMLScriptElement) scriptNodes.push(node);
      else host.appendChild(document.importNode(node, true));
    }

    // Load scripts from document.body, not from inside React's ad container.
    const liveScripts: HTMLScriptElement[] = [];
    for (const original of scriptNodes) {
      const script = document.createElement("script");
      for (const attr of Array.from(original.attributes)) script.setAttribute(attr.name, attr.value);
      if (original.src) script.src = original.src;
      else script.textContent = original.textContent;
      document.body.appendChild(script);
      liveScripts.push(script);
    }
    return () => {
      liveScripts.forEach((script) => script.remove());
      host.replaceChildren();
    };
  }, [code]);

  return <div ref={hostRef} aria-label={label} className="flex w-full justify-center" style={{ width: "100%", maxWidth: width, minHeight: height, overflow: "visible", position: "relative" }} />;
}
