import { useEffect, useMemo, useRef, useState } from "react";
import AdSlot from "./AdSlot";
import { AD_TOP_SIZE, SITE_URL } from "./config";
import adTop from "./ads/top.html?raw";

type AnimalType =
  | "capibara"
  | "tigre"
  | "buho"
  | "lobo"
  | "delfin"
  | "zorro";

type Question = {
  q: string;
  options: { text: string; type: AnimalType }[];
};

const questions: Question[] = [
  {
    q: "¿Cómo reaccionas ante un problema inesperado?",
    options: [
      { text: "🧘 Mantengo la calma y busco soluciones sin estresarme", type: "capibara" },
      { text: "⚡ Actúo de inmediato y tomo el control", type: "tigre" },
      { text: "🔍 Analizo en silencio antes de dar cualquier paso", type: "buho" },
      { text: "🐾 Prefiero resolverlo a mi manera y sin ayuda", type: "lobo" },
      { text: "😄 Lo tomo con humor y busco apoyo en los demás", type: "delfin" },
      { text: "🎭 Improviso una solución creativa en el momento", type: "zorro" },
    ],
  },
  {
    q: "¿Cuál es tu plan perfecto para un fin de semana?",
    options: [
      { text: "🍿 Maratón de series y comida rica en casa", type: "capibara" },
      { text: "🏔️ Una aventura al aire libre o deporte intenso", type: "tigre" },
      { text: "📚 Leer, aprender algo nuevo o explorar proyectos", type: "buho" },
      { text: "🎧 Salir a caminar solo o escuchar música a solas", type: "lobo" },
      { text: "🎉 Juntada con amigos, risas y buena música", type: "delfin" },
      { text: "🧩 Probar algo nuevo e improvisado sin plan fijo", type: "zorro" },
    ],
  },
  {
    q: "¿Qué superpoder elegirías?",
    options: [
      { text: "✨ Radiar paz absoluta a todos a mi alrededor", type: "capibara" },
      { text: "🔥 Fuerza sobrenatural e invencibilidad", type: "tigre" },
      { text: "🧠 Leer mentes y saber todo el conocimiento", type: "buho" },
      { text: "🥷 Invisibilidad para moverme libremente", type: "lobo" },
      { text: "💬 Hablar con cualquier persona o animal", type: "delfin" },
      { text: "🌀 Cambiar de forma a voluntad", type: "zorro" },
    ],
  },
  {
    q: "¿Cómo te describen tus amigos?",
    options: [
      { text: "La persona más pacífica y amigable", type: "capibara" },
      { text: "Líder natural, decidido y con carácter", type: "tigre" },
      { text: "La voz de la razón y consejero sabio", type: "buho" },
      { text: "Misterioso, independiente y leal", type: "lobo" },
      { text: "El alma de la fiesta, siempre positivo", type: "delfin" },
      { text: "Ingenioso, rápido y siempre un paso adelante", type: "zorro" },
    ],
  },
  {
    q: "¿Qué lugar elegirías para vivir?",
    options: [
      { text: "🏡 Una casita tranquila junto a un río", type: "capibara" },
      { text: "🌋 Un lugar salvaje, lejos de lo común", type: "tigre" },
      { text: "🏛️ Una ciudad con bibliotecas y museos", type: "buho" },
      { text: "🌲 Una cabaña aislada en el bosque", type: "lobo" },
      { text: "🏖️ Una playa llena de vida y gente", type: "delfin" },
      { text: "🌃 Una ciudad enorme llena de oportunidades", type: "zorro" },
    ],
  },
  {
    q: "En un trabajo en equipo, ¿qué rol asumes?",
    options: [
      { text: "El que calma tensiones y mantiene el ambiente sano", type: "capibara" },
      { text: "El que dirige y marca el rumbo", type: "tigre" },
      { text: "El que planifica y revisa los detalles", type: "buho" },
      { text: "El que trabaja por su cuenta y entrega resultados", type: "lobo" },
      { text: "El que motiva y une a todos", type: "delfin" },
      { text: "El que encuentra el atajo o la idea distinta", type: "zorro" },
    ],
  },
  {
    q: "¿Qué es lo que más valoras en la vida?",
    options: [
      { text: "La tranquilidad", type: "capibara" },
      { text: "El logro y el respeto", type: "tigre" },
      { text: "La sabiduría", type: "buho" },
      { text: "La libertad", type: "lobo" },
      { text: "Las relaciones y la alegría", type: "delfin" },
      { text: "La astucia y la aventura", type: "zorro" },
    ],
  },
  {
    q: "Si tuvieras un lema de vida, ¿cuál sería?",
    options: [
      { text: "\"Cero estrés, todo fluye.\"", type: "capibara" },
      { text: "\"El éxito es para los audaces.\"", type: "tigre" },
      { text: "\"El conocimiento es poder.\"", type: "buho" },
      { text: "\"Camino a mi propio ritmo.\"", type: "lobo" },
      { text: "\"La vida es mejor compartida.\"", type: "delfin" },
      { text: "\"Siempre hay otra salida.\"", type: "zorro" },
    ],
  },
];

const results: Record<AnimalType, { title: string; emoji: string; desc: string }> = {
  capibara: {
    title: "Capibara Relajado",
    emoji: "🦫",
    desc: "Tu aura emana paz y tranquilidad absoluta. Eres experto en evitar dramas y el refugio favorito de tus amigos cuando buscan calma.",
  },
  tigre: {
    title: "Tigre Determinado",
    emoji: "🐅",
    desc: "Tienes una energía indomable y una confianza arrolladora. No le temes a los retos y cuando quieres algo, trabajas hasta conseguirlo.",
  },
  buho: {
    title: "Búho Analítico",
    emoji: "🦉",
    desc: "Observas lo que otros ignoran. Tu inteligencia y prudencia te convierten en el estratega del grupo.",
  },
  lobo: {
    title: "Lobo Solitario",
    emoji: "🐺",
    desc: "Valoras enormemente tu independencia y tu espacio personal. Aunque eres reservado, tu lealtad hacia los tuyos es incondicional.",
  },
  delfin: {
    title: "Delfín Carismático",
    emoji: "🐬",
    desc: "Contagias alegría donde vas. Tu empatía y tu energía social hacen que la gente quiera tenerte cerca.",
  },
  zorro: {
    title: "Zorro Astuto",
    emoji: "🦊",
    desc: "Rápido de mente y siempre con un plan B. Te adaptas a cualquier situación y encuentras caminos donde otros ven muros.",
  },
};

const loadingMessages = [
  "Leyendo tu aura...",
  "Consultando a los animales...",
  "Analizando tus respuestas...",
  "Casi listo...",
];

const types = Object.keys(results) as AnimalType[];

type Phase = "quiz" | "loading" | "result";

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j]!, a[i]!];
  }
  return a;
}

function emptyScores(): Record<AnimalType, number> {
  return Object.fromEntries(types.map((t) => [t, 0])) as Record<AnimalType, number>;
}

export default function App() {
  const [phase, setPhase] = useState<Phase>("quiz");
  const [currentQ, setCurrentQ] = useState(0);
  const [round, setRound] = useState(0);
  const [scores, setScores] = useState<Record<AnimalType, number>>(emptyScores);
  const [locked, setLocked] = useState(false);
  const [loadingMsg, setLoadingMsg] = useState(loadingMessages[0]!);
  const [copied, setCopied] = useState(false);
  const lastAnswer = useRef<AnimalType | null>(null);

  // Opciones mezcladas por pregunta (evita sesgo de posición)
  const shuffled = useMemo(
    () => shuffle(questions[currentQ]!.options),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [currentQ, round],
  );

  // Ganador: en empate gana la última respuesta si está empatada; si no, al azar
  const winner = useMemo<AnimalType>(() => {
    const max = Math.max(...types.map((t) => scores[t]));
    const tied = types.filter((t) => scores[t] === max);
    if (lastAnswer.current && tied.includes(lastAnswer.current)) return lastAnswer.current;
    return tied[Math.floor(Math.random() * tied.length)] ?? "capibara";
  }, [scores]);

  useEffect(() => {
    if (phase !== "loading") return;
    let i = 0;
    setLoadingMsg(loadingMessages[0]!);
    const msgTimer = setInterval(() => {
      i = (i + 1) % loadingMessages.length;
      setLoadingMsg(loadingMessages[i] ?? loadingMessages[0]!);
    }, 900);
    const doneTimer = setTimeout(() => setPhase("result"), 3500);
    return () => {
      clearInterval(msgTimer);
      clearTimeout(doneTimer);
    };
  }, [phase]);

  function selectOption(type: AnimalType) {
    if (locked) return;
    setLocked(true);
    setScores((s) => ({ ...s, [type]: s[type] + 1 }));
    lastAnswer.current = type;
    const next = currentQ + 1;
    if (next < questions.length) {
      setCurrentQ(next);
      setLocked(false);
    } else {
      setPhase("loading");
    }
  }

  function restart() {
    setScores(emptyScores());
    lastAnswer.current = null;
    setCurrentQ(0);
    setRound((r) => r + 1);
    setLocked(false);
    setCopied(false);
    setPhase("quiz");
  }

  function pageUrl() {
    return SITE_URL || window.location.href.split("#")[0] || window.location.href;
  }

  function shareResult() {
    const r = results[winner];
    const text = `Me salió ${r.title} ${r.emoji} ¿Y a ti? Descúbrelo aquí: ${pageUrl()}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank");
  }

  async function copyLink() {
    try {
      await navigator.clipboard.writeText(pageUrl());
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      window.prompt("Copia este enlace:", pageUrl());
    }
  }

  const progress = phase === "loading" ? 100 : (currentQ / questions.length) * 100;

  return (
    <div className="flex min-h-screen flex-col items-center bg-background px-4 py-4 text-foreground">
      {/* BANNER SUPERIOR */}
      <div className="mb-5 flex w-full justify-center">
        <AdSlot code={adTop} width={AD_TOP_SIZE.width} height={AD_TOP_SIZE.height} label="Anuncio" />
      </div>

      <header className="mb-5 w-full max-w-xl text-center">
        <h1 className="bg-gradient-to-br from-gradient-from to-primary bg-clip-text text-3xl font-extrabold text-transparent">
          ¿Cuál es tu Espíritu Animal?
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Responde 8 preguntas rápidas y descubre tu aura oculta
        </p>
      </header>

      <main className="w-full max-w-xl rounded-2xl border border-border bg-card p-6 shadow-2xl">
        {phase === "quiz" && (
          <>
            <div className="mb-2 h-2 w-full overflow-hidden rounded-full bg-muted">
              <div
                className="h-full rounded-full bg-gradient-to-r from-gradient-from to-primary transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
            <p className="mb-4 text-right text-xs text-muted-foreground">
              Pregunta {currentQ + 1} de {questions.length}
            </p>
            <h2 className="mb-5 text-center text-lg font-semibold">{questions[currentQ]!.q}</h2>
            <div className="grid gap-3">
              {shuffled.map((opt) => (
                <button
                  key={opt.text}
                  onClick={() => selectOption(opt.type)}
                  className="rounded-xl border border-border bg-muted/40 px-5 py-4 text-left text-sm transition-all hover:-translate-y-0.5 hover:border-primary hover:bg-accent focus-visible:border-primary focus-visible:outline-none"
                >
                  {opt.text}
                </button>
              ))}
            </div>
          </>
        )}

        {phase === "loading" && (
          <div className="px-5 py-10 text-center">
            <div className="mx-auto mb-5 h-12 w-12 animate-spin rounded-full border-4 border-muted border-t-primary" />
            <h3>{loadingMsg}</h3>
          </div>
        )}

        {phase === "result" && (
          <div className="text-center">
            <div className="mb-2 text-7xl">{results[winner].emoji}</div>
            <h2 className="text-glow mb-2 text-2xl font-extrabold">{results[winner].title}</h2>
            <p className="mb-6 text-sm leading-relaxed text-muted-foreground">
              {results[winner].desc}
            </p>

            <button
              onClick={shareResult}
              className="mb-3 w-full rounded-xl bg-success py-3.5 text-base font-bold text-primary-foreground transition hover:brightness-110"
            >
              📲 Compartir en WhatsApp
            </button>
            <button
              onClick={copyLink}
              className="mb-3 w-full rounded-xl bg-secondary py-3.5 text-base font-bold text-secondary-foreground transition hover:brightness-110"
            >
              {copied ? "✅ ¡Enlace copiado!" : "🔗 Copiar enlace"}
            </button>
            <button
              onClick={restart}
              className="w-full rounded-xl border border-border py-2.5 text-sm text-muted-foreground transition hover:text-foreground"
            >
              Repetir test
            </button>
          </div>
        )}
      </main>
    </div>
  );
}
