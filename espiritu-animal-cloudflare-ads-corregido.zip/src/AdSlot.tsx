import { useEffect, useRef } from "react";

type Props = { code: string; width: number; height: number; label: string };

// Ejecuta los scripts publicitarios en el documento principal, no en un iframe.
export default function AdSlot({ code, width, height, label }: Props) {
  const hostRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;
    host.replaceChildren();
    const parsed = new DOMParser().parseFromString(code, "text/html");
    for (const node of Array.from(parsed.body.childNodes)) {
      if (node.nodeType === Node.TEXT_NODE && !node.textContent?.trim()) continue;
      if (node instanceof HTMLScriptElement) {
        const script = document.createElement("script");
        for (const attr of Array.from(node.attributes)) script.setAttribute(attr.name, attr.value);
        if (node.src) script.src = node.src;
        else script.textContent = node.textContent;
        host.appendChild(script);
      } else {
        host.appendChild(document.importNode(node, true));
      }
    }
    return () => { host.replaceChildren(); };
  }, [code]);

  return <div ref={hostRef} aria-label={label} className="flex w-full justify-center" style={{ width: "100%", maxWidth: width, minHeight: height, overflow: "visible" }} />;
}
