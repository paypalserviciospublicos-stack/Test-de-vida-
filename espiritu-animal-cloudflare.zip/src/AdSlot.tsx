type Props = {
  code: string; // contenido de src/ads/*.html
  width: number;
  height: number;
  label: string;
};

// Muestra el anuncio dentro de un iframe aislado: así los scripts de Adsterra
// (incluso los que usan document.write) funcionan aunque la app sea React.
export default function AdSlot({ code, width, height, label }: Props) {
  const clean = code.replace(/<!--[\s\S]*?-->/g, "").trim();

  if (!clean) {
    return (
      <div
        className="flex items-center justify-center rounded-lg border border-dashed border-border text-xs text-muted-foreground"
        style={{ width: "100%", maxWidth: width, minHeight: height }}
      >
        [ {label} ]
      </div>
    );
  }

  const srcDoc = `<!doctype html><html><head><meta charset="utf-8"><style>html,body{margin:0;padding:0;background:transparent;overflow:hidden}</style></head><body>${clean}</body></html>`;

  return (
    <iframe
      title={label}
      srcDoc={srcDoc}
      width={width}
      height={height}
      scrolling="no"
      style={{ border: 0, maxWidth: "100%" }}
    />
  );
}
