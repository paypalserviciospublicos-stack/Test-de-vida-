# ¿Cuál es tu Espíritu Animal?

Test de personalidad en React + Vite (página estática, misma estructura que MiTube).

## Cloudflare Pages
- Marco de trabajo: Ninguno
- Comando de compilación: `npm run build`
- Directorio de salida: `dist`

## Anuncios de Adsterra
- Banner superior: pega el código en `src/ads/top.html` (tamaño en `src/config.ts`).
- Banner del resultado: pega el código en `src/ads/result.html`.
- Usa una zona distinta para cada banner.

## Dominio
Cuando tengas dominio, escríbelo en `SITE_URL` (`src/config.ts`) y activa los meta tags `og:url` / `og:image` en `index.html`.
